
import os
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import PhotoImage

# Data wipe methods
WIPE_METHODS = {
    "Zero (2 Passes)": ["\x00", "\x00"],
    "US DOD (3 Passes)": ["\x00", "\xFF", "\x00"],
    "British HMG IS5 (3 Passes)": ["\xFF", "\x00", "\xAA"],
    "Russian GOST-R-50739-95 (3 Passes)": ["\x00", "\xFF", "\x00"],
    "NATO Standard (7 Passes)": ["\x00", "\xFF", "\x00", "\xFF", "\x00", "\xFF", "\x00"],
    "Peter Gutmann (35 Passes)": ["\xAA"] * 35
}

def wipe_file(file_path, method):
    if not os.path.isfile(file_path):
        return False
    size = os.path.getsize(file_path)
    try:
        with open(file_path, "r+b") as f:
            for pattern in WIPE_METHODS[method]:
                f.seek(0)
                f.write(bytes(pattern * size, encoding="latin-1"))
        os.remove(file_path)
        return True
    except Exception as e:
        print(f"Error wiping {file_path}: {e}")
        return False

def wipe_selection(selection_type):
    method = method_var.get()
    if not method:
        messagebox.showerror("Error", "Please select a wipe method")
        return

    if selection_type == "File":
        path = filedialog.askopenfilename()
        if path:
            if wipe_file(path, method):
                messagebox.showinfo("Success", f"Wiped file: {path}")
    elif selection_type == "Folder":
        folder = filedialog.askdirectory()
        if folder:
            success = True
            for root, dirs, files in os.walk(folder):
                for name in files:
                    file_path = os.path.join(root, name)
                    if not wipe_file(file_path, method):
                        success = False
            if success:
                messagebox.showinfo("Success", f"Wiped folder: {folder}")
            else:
                messagebox.showerror("Partial Success", "Some files could not be wiped.")
    elif selection_type in ["Disk", "Pen Drive"]:
        messagebox.showwarning("Not Supported", f"{selection_type} wipe not supported via Python GUI. Use dedicated tools like DBAN or PartedMagic.")

root = tk.Tk()
root.title("Secure Data Wiper")
root.geometry("400x500")
root.configure(bg="#f0f0f0")

method_var = tk.StringVar()

tk.Label(root, text="Select Wipe Method:", bg="#f0f0f0", font=("Arial", 12, "bold")).pack(pady=10)
method_menu = tk.OptionMenu(root, method_var, *WIPE_METHODS.keys())
method_menu.config(width=30)
method_menu.pack(pady=5)

icon_size = 32
file_icon = PhotoImage(file="file_icon.png").subsample(2, 2)
folder_icon = PhotoImage(file="folder_icon.png").subsample(2, 2)
disk_icon = PhotoImage(file="disk_icon.png").subsample(2, 2)
pendrive_icon = PhotoImage(file="usb_icon.png").subsample(2, 2)
partition_icon = PhotoImage(file="partition_icon.png").subsample(2, 2)

def create_icon_button(image, label, action_type):
    return tk.Button(
        root,
        image=image,
        text=label,
        compound="left",
        width=200,
        padx=10,
        anchor="w",
        command=lambda: wipe_selection(action_type)
    )

create_icon_button(disk_icon, "  Disk", "Disk").pack(pady=7)
create_icon_button(partition_icon, "  Partition", "Disk").pack(pady=7)
create_icon_button(pendrive_icon, "  Pen Drive", "Pen Drive").pack(pady=7)
create_icon_button(file_icon, "  File", "File").pack(pady=7)
create_icon_button(folder_icon, "  Folder", "Folder").pack(pady=7)

root.mainloop()
